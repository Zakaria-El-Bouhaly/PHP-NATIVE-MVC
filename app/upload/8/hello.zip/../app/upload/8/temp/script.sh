#!/usr/bin/bash

# echo "good morning sirs"

# echo "the price is $p$"

# Name=`neofetch`
# $Name >> file.txt


# if [[ p -gt 100 ]]
# then
# 	echo "too much"	
# fi

# if [[ -f "file.txt" ]];then echo "exists";fi

read -p "enter the username: " un

users=`ls /home/`