#/usr/bin/bash
s=1
x=1
while [[ $x -le 10 ]]; do
	s=$(echo "$s*$x" | bc -l)
	x=$((x+1))
done
echo $s