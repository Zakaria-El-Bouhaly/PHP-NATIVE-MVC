#/usr/bin/bash
# s=0
while [[ $x -le 10 ]]; do
	# s=$((s+x))
	echo $x
	x=$((x+1))

done
